
def add(a,b):
    
    return a+b

    
if __name__=="__main__":
    if add(2,2)==4 and add(5,0)==5:
        print ("test4 was successful")
    else:
        print("tesst4 was failure")
